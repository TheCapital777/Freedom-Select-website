import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { type, user_id, email, full_name } = await req.json()

    if (type === 'send_welcome_email') {
      // Get user's first name from full name
      const firstName = full_name ? full_name.split(' ')[0] : 'Valued Customer'
      
      // Send welcome email with verification
      const welcomeEmailContent = `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <title>Welcome to Freedom Select! Let's build something great together.</title>
          <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; background-color: #f8f9fa; }
            .container { max-width: 600px; margin: 0 auto; background-color: white; }
            .header { background: linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%); color: white; padding: 40px 30px; text-align: center; }
            .logo { font-family: 'Pacifico', serif; font-size: 32px; font-weight: bold; margin-bottom: 10px; }
            .header-subtitle { font-size: 18px; opacity: 0.9; }
            .content { padding: 40px 30px; }
            .greeting { font-size: 24px; font-weight: bold; color: #1f2937; margin-bottom: 20px; }
            .main-text { font-size: 16px; color: #4b5563; margin-bottom: 20px; }
            .highlight-text { font-size: 18px; color: #1f2937; font-weight: 600; margin: 30px 0 20px 0; }
            .verify-button { 
              display: inline-block; 
              background: linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%); 
              color: #000; 
              padding: 16px 32px; 
              text-decoration: none; 
              border-radius: 8px; 
              font-weight: bold; 
              font-size: 16px;
              margin: 25px 0; 
              text-align: center;
              box-shadow: 0 4px 12px rgba(251, 191, 36, 0.3);
            }
            .verify-button:hover { 
              background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); 
              box-shadow: 0 6px 16px rgba(251, 191, 36, 0.4);
            }
            .benefits-list { 
              background: #f9fafb; 
              padding: 25px; 
              border-radius: 8px; 
              margin: 25px 0; 
              border-left: 4px solid #fbbf24;
            }
            .benefits-list ul { 
              margin: 0; 
              padding: 0; 
              list-style: none; 
            }
            .benefits-list li { 
              margin: 12px 0; 
              padding-left: 25px; 
              position: relative; 
              color: #374151;
              font-size: 15px;
            }
            .benefits-list li:before { 
              content: '✓'; 
              position: absolute; 
              left: 0; 
              color: #10b981; 
              font-weight: bold; 
              font-size: 16px;
            }
            .closing-text { 
              font-size: 16px; 
              color: #4b5563; 
              margin: 30px 0 20px 0; 
            }
            .signature { 
              font-size: 16px; 
              color: #1f2937; 
              font-weight: 600; 
              margin-top: 30px; 
            }
            .footer { 
              background: #1f2937; 
              color: #9ca3af; 
              padding: 30px; 
              text-align: center; 
              font-size: 14px;
            }
            .footer-logo { 
              font-family: 'Pacifico', serif; 
              color: #fbbf24; 
              font-size: 24px; 
              margin-bottom: 15px; 
            }
            .button-container { text-align: center; margin: 30px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <div class="logo">Freedom Select</div>
              <div class="header-subtitle">Your One-Stop Marketplace</div>
            </div>
            
            <div class="content">
              <div class="greeting">Hi ${firstName},</div>
              
              <p class="main-text">
                Welcome to the Freedom Select family! We're thrilled to have you join our community, your new one-stop marketplace for modern furniture and quality building supplies.
              </p>
              
              <p class="main-text">
                Whether you're furnishing your dream home or tackling your next big project, we're here to make it easier, faster, and smarter.
              </p>
              
              <p class="highlight-text">
                To get started and unlock your personal dashboard, please click the link below to verify your email address:
              </p>
              
              <div class="button-container">
                <a href="${Deno.env.get('SUPABASE_URL')}/auth/v1/verify?token={{.Token}}&type=signup&redirect_to=${Deno.env.get('SITE_URL') || 'https://your-domain.com'}/dashboard" class="verify-button">
                  Verify Your Email & Start Shopping
                </a>
              </div>
              
              <div class="benefits-list">
                <p style="font-weight: 600; color: #1f2937; margin-bottom: 15px;">Once verified, you'll be able to:</p>
                <ul>
                  <li>Explore our carefully curated categories.</li>
                  <li>Connect with trusted transporters for seamless delivery.</li>
                  <li>Manage all your orders in one place.</li>
                </ul>
              </div>
              
              <p class="closing-text">
                Thank you for choosing Freedom Select. We're excited to help you bring your vision to life.
              </p>
              
              <p class="closing-text">
                Happy shopping!
              </p>
              
              <p class="signature">
                Best regards,<br>
                The Freedom Select Team
              </p>
            </div>
            
            <div class="footer">
              <div class="footer-logo">Freedom Select</div>
              <p>© ${new Date().getFullYear()} Freedom Select. All rights reserved.</p>
              <p>Tanzania's Premier E-Commerce Platform</p>
              <p style="font-size: 12px; margin-top: 15px;">
                If you didn't create this account, please ignore this email.
              </p>
            </div>
          </div>
        </body>
        </html>
      `

      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'Welcome email template ready',
          template: welcomeEmailContent
        }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        }
      )
    }

    if (type === 'verify_and_redirect') {
      const { data: user, error } = await supabaseClient.auth.admin.getUserById(user_id)
      
      if (error) {
        return new Response(
          JSON.stringify({ error: 'User not found' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 404 }
        )
      }

      const { error: updateError } = await supabaseClient.auth.admin.updateUserById(
        user_id,
        {
          user_metadata: {
            ...user.user_metadata,
            email_verified: true,
            welcome_email_sent: true,
            verification_date: new Date().toISOString()
          }
        }
      )

      if (updateError) {
        console.error('Error updating user metadata:', updateError)
      }

      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'User verified successfully',
          redirect_url: '/dashboard'
        }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        }
      )
    }

    return new Response(
      JSON.stringify({ error: 'Invalid request type' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
    )

  } catch (error) {
    console.error('Error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    )
  }
})