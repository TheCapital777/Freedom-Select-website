
import { useState } from 'react';
import { Link } from 'react-router-dom';
import Button from '../base/Button';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [cartCount] = useState(3);

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex-shrink-0 flex items-center">
            <div className="flex items-center space-x-2">
              <img 
                src="https://static.readdy.ai/image/2e1029d6ff4bf81528d7a00cbe43730c/b0927985bd43a4b7c33f0ee0bdb851be.png" 
                alt="Freedom Select Logo" 
                className="h-10 w-auto"
              />
              <div className="flex flex-col">
                <span className="text-xs text-gray-600 leading-tight">Your One Stop E-Commerce</span>
              </div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <Link to="/" className="text-gray-700 hover:text-yellow-500 font-medium transition-colors">Home</Link>
            <div className="relative group">
              <a href="#" className="text-gray-700 hover:text-yellow-500 font-medium transition-colors flex items-center">
                Categories <i className="ri-arrow-down-s-line ml-1"></i>
              </a>
              <div className="absolute top-full left-0 bg-white shadow-lg rounded-lg py-2 w-48 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                <a href="#" className="block px-4 py-2 text-gray-700 hover:bg-gray-50 hover:text-yellow-500">Furniture</a>
                <a href="#" className="block px-4 py-2 text-gray-700 hover:bg-gray-50 hover:text-yellow-500">Construction</a>
                <a href="#" className="block px-4 py-2 text-gray-500">Electronics (Coming Soon)</a>
                <a href="#" className="block px-4 py-2 text-gray-500">Home & Garden (Coming Soon)</a>
              </div>
            </div>
            <a href="#" className="text-gray-700 hover:text-yellow-500 font-medium transition-colors">Deals</a>
            <a href="#" className="text-gray-700 hover:text-yellow-500 font-medium transition-colors">About</a>
            <a href="#" className="text-gray-700 hover:text-yellow-500 font-medium transition-colors">Contact</a>
          </nav>

          {/* Desktop Actions */}
          <div className="hidden md:flex items-center space-x-4">
            <div className="relative">
              <input
                type="text"
                placeholder="Search everything..."
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent text-sm w-64"
              />
              <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-sm"></i>
            </div>
            <button className="relative p-2 text-gray-700 hover.text-yellow-500 transition-colors">
              <i className="ri-shopping-cart-line text-xl"></i>
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-yellow-500 text-black text-xs rounded-full h-5 w-5 flex items-center justify-center font-bold">
                  {cartCount}
                </span>
              )}
            </button>
            <Link to="/auth/login">
              <Button size="sm">Sign In</Button>
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center space-x-2">
            <button className="relative p-2 text-gray-700">
              <i className="ri-shopping-cart-line text-xl"></i>
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-yellow-500 text-black text-xs rounded-full h-4 w-4 flex items-center justify-center font-bold">
                  {cartCount}
                </span>
              )}
            </button>
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 text-gray-700 hover:text-yellow-500 transition-colors"
            >
              <i className={`ri-${isMenuOpen ? 'close' : 'menu'}-line text-xl`}></i>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-200">
          <div className="px-4 py-3 space-y-3">
            <div className="relative">
              <input
                type="text"
                placeholder="Search everything..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent text-sm"
              />
              <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-sm"></i>
            </div>
            <nav className="flex flex-col space-y-2">
              <Link to="/" className="py-2 text-gray-700 hover:text-yellow-500 font-medium transition-colors">Home</Link>
              <a href="#" className="py-2 text-gray-700 hover:text-yellow-500 font-medium transition-colors">Furniture</a>
              <a href="#" className="py-2 text-gray-700 hover:text-yellow-500 font-medium transition-colors">Construction</a>
              <a href="#" className="py-2 text-gray-500">Electronics (Coming Soon)</a>
              <a href="#" className="py-2 text-gray-700 hover:text-yellow-500 font-medium transition-colors">Deals</a>
              <a href="#" className="py-2 text-gray-700 hover:text-yellow-500 font-medium transition-colors">About</a>
              <a href="#" className="py-2 text-gray-700 hover:text-yellow-500 font-medium transition-colors">Contact</a>
            </nav>
            <Link to="/auth/login">
              <Button className="w-full" size="sm">Sign In</Button>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
