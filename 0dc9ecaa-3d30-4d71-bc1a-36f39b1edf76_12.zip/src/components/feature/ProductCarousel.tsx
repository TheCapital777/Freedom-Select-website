
import { useState } from 'react';
import Button from '../base/Button';

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  category: string;
  rating: number;
  reviews: number;
}

export default function ProductCarousel() {
  const [currentSlide, setCurrentSlide] = useState(0);
  
  const featuredProducts: Product[] = [
    {
      id: 1,
      name: "Modern Scandinavian Sofa Set",
      price: 2850000,
      image: "https://readdy.ai/api/search-image?query=Elegant%20modern%20Scandinavian%20three-piece%20sofa%20set%20in%20neutral%20gray%20fabric%20with%20wooden%20legs%2C%20minimalist%20design%2C%20clean%20white%20background%2C%20professional%20product%20photography%2C%20high-end%20furniture%20showroom%20quality&width=400&height=400&seq=sofa-1&orientation=squarish",
      category: "Furniture",
      rating: 4.8,
      reviews: 124
    },
    {
      id: 2,
      name: "Premium Steel Roofing Sheets",
      price: 45000,
      image: "https://readdy.ai/api/search-image?query=High-quality%20galvanized%20steel%20roofing%20sheets%20stacked%20professionally%2C%20metallic%20silver%20finish%2C%20construction%20materials%2C%20industrial%20clean%20background%2C%20professional%20product%20photography%20for%20building%20supplies&width=400&height=400&seq=roofing-1&orientation=squarish",
      category: "Construction",
      rating: 4.9,
      reviews: 89
    },
    {
      id: 3,
      name: "Executive Office Desk",
      price: 1250000,
      image: "https://readdy.ai/api/search-image?query=Sophisticated%20executive%20office%20desk%20in%20dark%20walnut%20wood%20finish%20with%20modern%20metal%20accents%2C%20clean%20lines%2C%20professional%20workspace%20furniture%2C%20white%20background%2C%20high-end%20business%20furniture%20photography&width=400&height=400&seq=desk-1&orientation=squarish",
      category: "Furniture",
      rating: 4.7,
      reviews: 67
    },
    {
      id: 4,
      name: "Ceramic Floor Tiles Premium",
      price: 18500,
      image: "https://readdy.ai/api/search-image?query=Beautiful%20premium%20ceramic%20floor%20tiles%20in%20elegant%20marble%20pattern%2C%20glossy%20finish%2C%20construction%20materials%2C%20tiles%20displayed%20professionally%2C%20clean%20white%20background%2C%20architectural%20materials%20photography&width=400&height=400&seq=tiles-1&orientation=squarish",
      category: "Construction",
      rating: 4.6,
      reviews: 156
    },
    {
      id: 5,
      name: "Designer Dining Table Set",
      price: 1850000,
      image: "https://readdy.ai/api/search-image?query=Modern%20designer%20dining%20table%20set%20with%20six%20chairs%2C%20contemporary%20style%2C%20natural%20wood%20finish%20with%20upholstered%20seats%2C%20elegant%20dining%20room%20furniture%2C%20clean%20white%20background%2C%20luxury%20furniture%20photography&width=400&height=400&seq=dining-1&orientation=squarish",
      category: "Furniture",
      rating: 4.9,
      reviews: 203
    },
    {
      id: 6,
      name: "Professional Paint Set",
      price: 125000,
      image: "https://readdy.ai/api/search-image?query=Professional%20paint%20buckets%20and%20brushes%20set%20for%20construction%2C%20various%20colors%20including%20white%20and%20neutral%20tones%2C%20construction%20supplies%2C%20clean%20organized%20display%2C%20professional%20building%20materials%20photography&width=400&height=400&seq=paint-1&orientation=squarish",
      category: "Construction",
      rating: 4.5,
      reviews: 78
    },
    {
      id: 15,
      name: "Smart LED TV 55 inch",
      price: 1450000,
      image: "https://readdy.ai/api/search-image?query=Modern%2055%20inch%20smart%20LED%20television%20with%20ultra-thin%20bezels%2C%204K%20display%2C%20sleek%20black%20frame%2C%20electronics%20product%20photography%2C%20clean%20white%20background%2C%20premium%20home%20entertainment%20device&width=400&height=400&seq=tv-1&orientation=squarish",
      category: "Electronics",
      rating: 4.7,
      reviews: 92
    },
    {
      id: 16,
      name: "Garden Tool Set Premium",
      price: 280000,
      image: "https://readdy.ai/api/search-image?query=Complete%20premium%20garden%20tool%20set%20with%20spades%2C%20rakes%2C%20pruning%20shears%2C%20watering%20ca%20n%2C%20organized%20in%20wooden%20box%2C%20gardening%20equipment%2C%20clean%20white%20background%2C%20home%20and%20garden%20supplies%20photography&width=400&height=400&seq=garden-1&orientation=squarish",
      category: "Home & Garden",
      rating: 4.8,
      reviews: 156
    }
  ];

  const itemsPerSlide = 4;
  const totalSlides = Math.ceil(featuredProducts.length / itemsPerSlide);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % totalSlides);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + totalSlides) % totalSlides);
  };

  const formatPrice = (price: number) => {
    return `TZS ${price.toLocaleString()}`;
  };

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-black mb-4">Featured Products</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Discover our handpicked selection from furniture, construction supplies, and expanding categories
          </p>
        </div>

        <div className="relative">
          {/* Carousel Container */}
          <div className="overflow-hidden">
            <div 
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${currentSlide * 100}%)` }}
            >
              {Array.from({ length: totalSlides }).map((_, slideIndex) => (
                <div key={slideIndex} className="w-full flex-shrink-0">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {featuredProducts
                      .slice(slideIndex * itemsPerSlide, (slideIndex + 1) * itemsPerSlide)
                      .map((product) => (
                        <div key={product.id} className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 overflow-hidden group cursor-pointer" data-product-shop>
                          <div className="relative overflow-hidden">
                            <img
                              src={product.image}
                              alt={product.name}
                              className="w-full h-64 object-cover object-top group-hover:scale-105 transition-transform duration-300"
                            />
                            <div className="absolute top-4 left-4">
                              <span className="bg-yellow-500 text-black px-3 py-1 rounded-full text-sm font-semibold">
                                {product.category}
                              </span>
                            </div>
                            <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                              <button className="bg-white text-gray-700 hover:text-red-500 p-2 rounded-full shadow-lg transition-colors">
                                <i className="ri-heart-line text-lg"></i>
                              </button>
                            </div>
                          </div>
                          <div className="p-6">
                            <h3 className="text-lg font-semibold text-black mb-2 line-clamp-2">
                              {product.name}
                            </h3>
                            <div className="flex items-center mb-3">
                              <div className="flex text-yellow-500">
                                {[...Array(5)].map((_, i) => (
                                  <i key={i} className={`ri-star-${i < Math.floor(product.rating) ? 'fill' : 'line'} text-sm`}></i>
                                ))}
                              </div>
                              <span className="text-gray-500 text-sm ml-2">({product.reviews})</span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-2xl font-bold text-black">
                                {formatPrice(product.price)}
                              </span>
                              <Button size="sm" className="px-4">
                                <i className="ri-shopping-cart-line mr-1"></i>
                                Add
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Navigation Arrows */}
          <button
            onClick={prevSlide}
            className="absolute left-0 top-1/2 transform -translate-y-1/2 -translate-x-4 bg-white shadow-lg rounded-full p-3 hover:bg-gray-50 transition-colors z-10"
          >
            <i className="ri-arrow-left-line text-xl text-gray-700"></i>
          </button>
          <button
            onClick={nextSlide}
            className="absolute right-0 top-1/2 transform -translate-y-1/2 translate-x-4 bg-white shadow-lg rounded-full p-3 hover:bg-gray-50 transition-colors z-10"
          >
            <i className="ri-arrow-right-line text-xl text-gray-700"></i>
          </button>

          {/* Dots Indicator */}
          <div className="flex justify-center mt-8 space-x-2">
            {Array.from({ length: totalSlides }).map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-3 h-3 rounded-full transition-colors ${
                  index === currentSlide ? 'bg-yellow-500' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>
        </div>

        <div className="text-center mt-12">
          <Button size="lg" variant="outline" className="border-black text-black hover:bg-black hover:text-white">
            View All Categories
            <i className="ri-arrow-right-line ml-2"></i>
          </Button>
        </div>
      </div>
    </section>
  );
}
