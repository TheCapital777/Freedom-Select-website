
import Button from '../base/Button';
import { Link } from 'react-router-dom';

export default function Hero() {
  return (
    <section 
      className="relative h-screen flex items-center justify-center bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), url('https://readdy.ai/api/search-image?query=Modern%20e-commerce%20marketplace%20scene%20with%20Freedom%20Select%20branding%2C%20diverse%20products%20including%20premium%20furniture%20sofa%20sets%2C%20construction%20materials%20cement%20bags%2C%20electronics%2C%20home%20appliances%2C%20all%20arranged%20in%20elegant%20warehouse%20setting%20with%20golden%20yellow%20and%20black%20branding%2C%20professional%20delivery%20trucks%20in%20background%2C%20comprehensive%20shopping%20experience%2C%20Tanzania%20marketplace%20aesthetic&width=1920&height=1080&seq=hero-ecommerce&orientation=landscape')`
      }}
    >
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center text-white">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            <span className="text-yellow-500">Freedom Select</span><br />
            Your One Stop <span className="text-yellow-500">E-Commerce</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto leading-relaxed">
            Starting with premium furniture and construction supplies, expanding to everything you need. Quality products, reliable delivery across Tanzania.
          </p>
          
          {/* Product Categories Preview */}
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <div className="bg-white/20 backdrop-blur-sm rounded-full px-6 py-2 text-white border border-white/30">
              <i className="ri-sofa-line mr-2"></i>Premium Furniture
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-full px-6 py-2 text-white border border-white/30">
              <i className="ri-hammer-line mr-2"></i>Construction Supplies
            </div>
            <div className="bg-yellow-500/20 backdrop-blur-sm rounded-full px-6 py-2 text-yellow-300 border border-yellow-300/30">
              <i className="ri-more-line mr-2"></i>More Categories Coming Soon
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link to="/auth/signup">
              <Button size="lg" className="text-lg px-10 py-4">
                <i className="ri-shopping-bag-line mr-2 text-xl"></i>
                Start Shopping
              </Button>
            </Link>
            <Button variant="outline" size="lg" className="text-lg px-10 py-4 border-white text-white hover:bg-white hover:text-black">
              <i className="ri-store-line mr-2 text-xl"></i>
              Explore Categories
            </Button>
          </div>
        </div>
      </div>
      
      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <i className="ri-arrow-down-line text-white text-2xl"></i>
      </div>
    </section>
  );
}
