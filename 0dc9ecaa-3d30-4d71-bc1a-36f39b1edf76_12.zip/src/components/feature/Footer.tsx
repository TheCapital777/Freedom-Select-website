
export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-black text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-6">
            <div className="flex items-center space-x-2">
              <img 
                src="https://static.readdy.ai/image/2e1029d6ff4bf81528d7a00cbe43730c/b0927985bd43a4b7c33f0ee0bdb851be.png" 
                alt="Freedom Select Logo" 
                className="h-10 w-auto"
              />
            </div>
            <p className="text-gray-300 leading-relaxed">
              Tanzania's premier destination for modern furniture and professional construction materials. Quality you can trust, service you can rely on.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-yellow-500 transition-colors">
                <i className="ri-facebook-fill text-2xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-yellow-500 transition-colors">
                <i className="ri-instagram-line text-2xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-yellow-500 transition-colors">
                <i className="ri-twitter-fill text-2xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-yellow-500 transition-colors">
                <i className="ri-linkedin-fill text-2xl"></i>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-6 text-yellow-500">Quick Links</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Home</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Furniture</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Construction</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">About Us</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Contact</a></li>
              <li><a href="https://readdy.ai/?origin=logo" className="text-gray-300 hover:text-yellow-500 transition-colors">Made with Readdy</a></li>
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h3 className="text-lg font-semibold mb-6 text-yellow-500">Customer Service</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Help Center</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Shipping Info</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Returns &amp; Exchanges</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Size Guide</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Track Your Order</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Warranty</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-6 text-yellow-500">Contact Info</h3>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <i className="ri-map-pin-line text-yellow-500 text-xl mt-1"></i>
                <div>
                  <p className="text-gray-300">Uhuru Street, Plot 123</p>
                  <p className="text-gray-300">Dar es Salaam, Tanzania</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <i className="ri-phone-line text-yellow-500 text-xl"></i>
                <p className="text-gray-300">+255 22 123 4567</p>
              </div>
              <div className="flex items-center space-x-3">
                <i className="ri-mail-line text-yellow-500 text-xl"></i>
                <p className="text-gray-300">info@freedomselect.co.tz</p>
              </div>
              <div className="flex items-center space-x-3">
                <i className="ri-time-line text-yellow-500 text-xl"></i>
                <div>
                  <p className="text-gray-300">Mon - Sat: 8:00 AM - 8:00 PM</p>
                  <p className="text-gray-300">Sunday: 10:00 AM - 6:00 PM</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-gray-400 text-sm">
              © {currentYear} Freedom Select. All rights reserved.
            </p>
            <div className="flex items-center space-x-6">
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Privacy Policy</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Terms of Service</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Cookie Policy</a>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-gray-400 text-sm">We Accept:</span>
              <div className="flex space-x-2">
                <i className="ri-visa-line text-2xl text-gray-400"></i>
                <i className="ri-mastercard-line text-2xl text-gray-400"></i>
                <i className="ri-smartphone-line text-2xl text-yellow-500"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
