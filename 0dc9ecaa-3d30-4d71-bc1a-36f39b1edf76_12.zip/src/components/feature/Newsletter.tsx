
import { useState } from 'react';
import Button from '../base/Button';

export default function Newsletter() {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || isSubmitting) return;
    
    setIsSubmitting(true);
    
    try {
      const formData = new URLSearchParams();
      formData.append('email', email);
      
      const response = await fetch('https://readdy.ai/api/form/d35r9u678msbhm7e6tag', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formData.toString()
      });
      
      if (response.ok) {
        setIsSubmitted(true);
        setTimeout(() => {
          setIsSubmitted(false);
          setEmail('');
        }, 3000);
      }
    } catch (error) {
      console.error('Form submission error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section 
      className="py-20 bg-cover bg-center bg-no-repeat relative"
      style={{
        backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('https://readdy.ai/api/search-image?query=Modern%20warehouse%20filled%20with%20premium%20furniture%20and%20construction%20materials%2C%20organized%20storage%20with%20golden%20yellow%20accent%20lighting%2C%20professional%20logistics%20center%2C%20Tanzania%20delivery%20network%2C%20high-quality%20industrial%20photography&width=1920&height=600&seq=newsletter-bg&orientation=landscape')`
      }}
    >
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
          Stay Updated with <span className="text-yellow-500">Freedom Select</span>
        </h2>
        <p className="text-xl text-gray-200 mb-8 max-w-2xl mx-auto">
          Get exclusive deals, new product launches, and expert tips delivered straight to your inbox
        </p>

        {!isSubmitted ? (
          <form onSubmit={handleSubmit} className="max-w-md mx-auto flex flex-col sm:flex-row gap-4" data-readdy-form id="newsletter-subscription">
            <input
              type="email"
              name="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email address"
              className="flex-1 px-6 py-4 rounded-lg border border-gray-300 focus:ring-2 focus:ring-yellow-500 focus:border-transparent text-lg"
              required
            />
            <Button type="submit" size="lg" className="px-8 py-4 text-lg whitespace-nowrap" disabled={isSubmitting}>
              <i className="ri-mail-send-line mr-2"></i>
              {isSubmitting ? 'Subscribing...' : 'Subscribe Now'}
            </Button>
          </form>
        ) : (
          <div className="max-w-md mx-auto bg-green-100 border border-green-400 text-green-700 px-6 py-4 rounded-lg">
            <i className="ri-check-circle-line mr-2"></i>
            Thank you for subscribing! Check your email for confirmation.
          </div>
        )}

        <p className="text-gray-300 text-sm mt-6">
          Join over 15,000 satisfied customers. Unsubscribe anytime.
        </p>
      </div>
    </section>
  );
}
