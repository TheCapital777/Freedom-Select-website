import Button from '../base/Button';

interface Category {
  id: number;
  name: string;
  description: string;
  image: string;
  itemCount: number;
  available: boolean;
  comingSoon?: boolean;
}

export default function CategoryShowcase() {
  const categories: Category[] = [
    {
      id: 1,
      name: "Premium Furniture",
      description: "Modern sofas, dining sets, office furniture & bedroom collections",
      image: "https://readdy.ai/api/search-image?query=Elegant%20modern%20furniture%20showroom%20with%20various%20premium%20furniture%20pieces%20including%20sofas%2C%20dining%20tables%2C%20office%20chairs%2C%20bedroom%20sets%2C%20contemporary%20interior%20design%2C%20clean%20organized%20display%2C%20golden%20yellow%20and%20black%20accents&width=500&height=300&seq=furniture-category&orientation=landscape",
      itemCount: 150,
      available: true
    },
    {
      id: 2,
      name: "Construction Supplies",
      description: "Cement, roofing, tiles, hardware & building materials",
      image: "https://readdy.ai/api/search-image?query=Professional%20construction%20materials%20warehouse%20with%20cement%20bags%2C%20roofing%20sheets%2C%20tiles%2C%20hardware%20tools%2C%20organized%20building%20supplies%20storage%2C%20industrial%20clean%20environment%2C%20construction%20industry%20photography&width=500&height=300&seq=construction-category&orientation=landscape",
      itemCount: 120,
      available: true
    },
    {
      id: 3,
      name: "Electronics",
      description: "TVs, smartphones, laptops & home appliances",
      image: "https://readdy.ai/api/search-image?query=Modern%20electronics%20store%20display%20with%20smart%20TVs%2C%20smartphones%2C%20laptops%2C%20home%20appliances%2C%20organized%20technology%20products%2C%20sleek%20modern%20retail%20environment%2C%20electronic%20devices%20showcase&width=500&height=300&seq=electronics-category&orientation=landscape",
      itemCount: 0,
      available: false,
      comingSoon: true
    },
    {
      id: 4,
      name: "Home & Garden",
      description: "Garden tools, outdoor furniture & home accessories",
      image: "https://readdy.ai/api/search-image?query=Beautiful%20home%20and%20garden%20section%20with%20outdoor%20furniture%2C%20garden%20tools%2C%20planters%2C%20outdoor%20decor%2C%20gardening%20supplies%2C%20modern%20patio%20furniture%20display%2C%20home%20improvement%20store%20atmosphere&width=500&height=300&seq=garden-category&orientation=landscape",
      itemCount: 0,
      available: false,
      comingSoon: true
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-black mb-4">Shop by Category</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Starting with premium furniture and construction supplies, expanding to serve all your needs
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {categories.map((category) => (
            <div 
              key={category.id} 
              className={`relative rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 ${
                category.available ? 'cursor-pointer group' : 'opacity-75'
              }`}
            >
              <div className="relative h-64">
                <img
                  src={category.image}
                  alt={category.name}
                  className={`w-full h-full object-cover object-top ${
                    category.available ? 'group-hover:scale-105' : ''
                  } transition-transform duration-300`}
                />
                <div className="absolute inset-0 bg-black bg-opacity-40"></div>
                
                {/* Status Badge */}
                <div className="absolute top-4 left-4">
                  {category.available ? (
                    <span className="bg-green-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
                      Available Now
                    </span>
                  ) : (
                    <span className="bg-yellow-500 text-black px-3 py-1 rounded-full text-sm font-semibold">
                      Coming Soon
                    </span>
                  )}
                </div>

                {/* Content */}
                <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                  <h3 className="text-2xl font-bold mb-2">{category.name}</h3>
                  <p className="text-gray-200 mb-3">{category.description}</p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      {category.available && (
                        <span className="text-yellow-300 font-semibold">
                          {category.itemCount}+ Items
                        </span>
                      )}
                    </div>
                    
                    {category.available ? (
                      <Button size="sm" className="bg-yellow-500 hover:bg-yellow-600 text-black">
                        Shop Now
                        <i className="ri-arrow-right-line ml-2"></i>
                      </Button>
                    ) : (
                      <Button size="sm" variant="outline" className="border-white text-white hover:bg-white hover:text-black" disabled>
                        Notify Me
                        <i className="ri-notification-line ml-2"></i>
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Expansion Message */}
        <div className="text-center bg-white rounded-xl p-8 shadow-lg">
          <div className="max-w-3xl mx-auto">
            <h3 className="text-2xl font-bold text-black mb-4">Building Tanzania's Premier E-Commerce Platform</h3>
            <p className="text-gray-600 mb-6">
              We're starting with what we do best - premium furniture and construction supplies. 
              Soon we'll expand to electronics, home & garden, fashion, and everything else you need.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg">
                <i className="ri-store-line mr-2"></i>
                Shop Current Categories
              </Button>
              <Button size="lg" variant="outline" className="border-black text-black hover:bg-black hover:text-white">
                <i className="ri-mail-line mr-2"></i>
                Get Notified of New Categories
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}