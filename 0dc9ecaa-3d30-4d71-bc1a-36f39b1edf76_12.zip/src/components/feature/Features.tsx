
export default function Features() {
  const features = [
    {
      icon: 'ri-truck-line',
      title: 'Nationwide Delivery',
      description: 'Fast and reliable delivery across all regions of Tanzania with professional handling.'
    },
    {
      icon: 'ri-shield-check-line',
      title: 'Quality Guaranteed',
      description: 'All products undergo strict quality checks before reaching your doorstep.'
    },
    {
      icon: 'ri-24-hours-line',
      title: '24/7 Support',
      description: 'Round-the-clock customer support to assist you with any questions or concerns.'
    },
    {
      icon: 'ri-secure-payment-line',
      title: 'Secure Payments',
      description: 'Multiple secure payment options including mobile money and bank transfers.'
    },
    {
      icon: 'ri-price-tag-3-line',
      title: 'Best Prices',
      description: 'Competitive pricing with regular deals and discounts for all categories.'
    },
    {
      icon: 'ri-store-3-line',
      title: 'Growing Marketplace',
      description: 'Expanding from furniture & construction to become your complete shopping destination.'
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-black mb-4">Why Choose Freedom Select?</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Your trusted e-commerce partner in Tanzania, committed to excellence in every transaction
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="text-center p-6 rounded-xl bg-gray-50 hover:bg-yellow-50 transition-colors duration-300 group">
              <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                <i className={`${feature.icon} text-2xl text-black`}></i>
              </div>
              <h3 className="text-xl font-semibold text-black mb-3">{feature.title}</h3>
              <p className="text-gray-600 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
