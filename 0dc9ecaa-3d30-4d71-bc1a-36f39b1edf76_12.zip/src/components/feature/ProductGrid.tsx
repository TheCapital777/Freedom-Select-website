
import { useState } from 'react';
import Button from '../base/Button';

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  category: string;
  rating: number;
  reviews: number;
  discount?: number;
  isNew?: boolean;
}

export default function ProductGrid() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [sortBy, setSortBy] = useState('featured');

  const categories = ['All', 'Furniture', 'Construction', 'Electronics', 'Home & Garden', 'Best Sellers'];

  const products: Product[] = [
    {
      id: 7,
      name: "Luxury Bedroom Set Complete",
      price: 3200000,
      image: "https://readdy.ai/api/search-image?query=Luxurious%20complete%20bedroom%20set%20with%20king%20size%20bed%2C%20two%20nightstands%2C%20and%20elegant%20dresser%20in%20rich%20mahogany%20wood%20finish%2C%20hotel-style%20bedding%2C%20modern%20sophisticated%20furniture%2C%20clean%20white%20background&width=350&height=350&seq=bedroom-1&orientation=squarish",
      category: "Furniture",
      rating: 4.9,
      reviews: 89,
      isNew: true
    },
    {
      id: 8,
      name: "Industrial Cement Bags",
      price: 28000,
      image: "https://readdy.ai/api/search-image?query=Professional%20cement%20bags%20stacked%20neatly%2C%20industrial%20construction%20materials%2C%20gray%20cement%20packaging%2C%20building%20supplies%20for%20construction%20projects%2C%20clean%20industrial%20background&width=350&height=350&seq=cement-1&orientation=squarish",
      category: "Construction",
      rating: 4.7,
      reviews: 156
    },
    {
      id: 9,
      name: "Modern Coffee Table Glass",
      price: 450000,
      image: "https://readdy.ai/api/search-image?query=Elegant%20modern%20glass%20coffee%20table%20with%20sleek%20metal%20frame%2C%20contemporary%20living%20room%20furniture%2C%20transparent%20tempered%20glass%20top%2C%20minimalist%20design%2C%20clean%20white%20background&width=350&height=350&seq=coffee-table-1&orientation=squarish",
      category: "Furniture",
      rating: 4.6,
      reviews: 203,
      discount: 15
    },
    {
      id: 10,
      name: "Premium Door Hardware Set",
      price: 85000,
      image: "https://readdy.ai/api/search-image?query=Premium%20door%20hardware%20set%20including%20handles%2C%20locks%2C%20and%20hinges%20in%20brushed%20stainless%20steel%20finish%2C%20construction%20hardware%2C%20professional%20building%20accessories%2C%20clean%20product%20photography&width=350&height=350&seq=hardware-1&orientation=squarish",
      category: "Construction",
      rating: 4.8,
      reviews: 67
    },
    {
      id: 11,
      name: "Executive Leather Chair",
      price: 890000,
      image: "https://readdy.ai/api/search-image?query=Premium%20executive%20leather%20office%20chair%20in%20rich%20brown%20leather%20with%20ergonomic%20design%2C%20high-back%20professional%20seating%2C%20modern%20office%20furniture%2C%20clean%20white%20background&width=350&height=350&seq=chair-1&orientation=squarish",
      category: "Furniture",
      rating: 4.9,
      reviews: 124,
      isNew: true
    },
    {
      id: 12,
      name: "Electrical Wiring Bundle",
      price: 120000,
      image: "https://readdy.ai/api/search-image?query=Professional%20electrical%20wiring%20cables%20and%20supplies%20bundle%2C%20copper%20wiring%20for%20construction%2C%20electrical%20materials%2C%20organized%20display%20of%20construction%20electrical%20components%2C%20clean%20background&width=350&height=350&seq=wiring-1&orientation=squarish",
      category: "Construction",
      rating: 4.5,
      reviews: 98
    },
    {
      id: 13,
      name: "Designer Bookshelf Unit",
      price: 750000,
      image: "https://readdy.ai/api/search-image?query=Modern%20designer%20bookshelf%20unit%20in%20white%20and%20natural%20wood%20combination%2C%20contemporary%20storage%20furniture%2C%20clean%20geometric%20design%2C%20perfect%20for%20modern%20homes%2C%20clean%20white%20background&width=350&height=350&seq=bookshelf-1&orientation=squarish",
      category: "Furniture",
      rating: 4.7,
      reviews: 145,
      discount: 20
    },
    {
      id: 14,
      name: "Concrete Blocks Premium",
      price: 1200,
      image: "https://readdy.ai/api/search-image?query=High-quality%20concrete%20building%20blocks%20stacked%20professionally%2C%20construction%20materials%2C%20gray%20concrete%20blocks%20for%20building%2C%20construction%20supplies%2C%20industrial%20clean%20background&width=350&height=350&seq=blocks-1&orientation=squarish",
      category: "Construction",
      rating: 4.6,
      reviews: 234
    },
    {
      id: 17,
      name: "Smart Home Security Camera",
      price: 380000,
      image: "https://readdy.ai/api/search-image?query=Modern%20wireless%20security%20camera%20with%20night%20vision%2C%20smart%20home%20device%2C%20white%20sleek%20design%2C%20electronics%20product%20photography%2C%20clean%20white%20background%2C%20home%20security%20equipment&width=350&height=350&seq=camera-1&orientation=squarish",
      category: "Electronics",
      rating: 4.8,
      reviews: 76
    },
    {
      id: 18,
      name: "Outdoor Patio Furniture Set",
      price: 1650000,
      image: "https://readdy.ai/api/search-image?query=Beautiful%20outdoor%20patio%20furniture%20set%20with%20table%20and%20four%20chairs%2C%20weather-resistant%20materials%2C%20modern%20garden%20furniture%2C%20outdoor%20dining%20set%2C%20clean%20white%20background%2C%20home%20and%20garden%20category&width=350&height=350&seq=patio-1&orientation=squarish",
      category: "Home & Garden",
      rating: 4.7,
      reviews: 112
    }
  ];

  const filteredProducts = products.filter(product => 
    selectedCategory === 'All' || 
    product.category === selectedCategory ||
    (selectedCategory === 'New Arrivals' && product.isNew) ||
    (selectedCategory === 'Best Sellers' && product.rating >= 4.8)
  );

  const formatPrice = (price: number) => {
    return `TZS ${price.toLocaleString()}`;
  };

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-black mb-4">All Products</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Browse our growing collection across multiple categories - from furniture to electronics
          </p>
        </div>

        {/* Filter and Sort Controls */}
        <div className="flex flex-col md:flex-row justify-between items-center mb-8 space-y-4 md:space-y-0">
          {/* Category Filter */}
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-full font-medium transition-colors whitespace-nowrap ${
                  selectedCategory === category
                    ? 'bg-yellow-500 text-black'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Sort Dropdown */}
          <div className="flex items-center space-x-4">
            <span className="text-gray-600">Sort by:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent pr-8"
            >
              <option value="featured">Featured</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
              <option value="rating">Highest Rated</option>
              <option value="newest">Newest First</option>
            </select>
          </div>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-12">
          {filteredProducts.map((product) => (
            <div key={product.id} className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group cursor-pointer border border-gray-100" data-product-shop>
              <div className="relative overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-64 object-cover object-top group-hover:scale-105 transition-transform duration-300"
                />
                
                {/* Badges */}
                <div className="absolute top-4 left-4 flex flex-col space-y-2">
                  <span className="bg-yellow-500 text-black px-3 py-1 rounded-full text-sm font-semibold">
                    {product.category}
                  </span>
                  {product.isNew && (
                    <span className="bg-green-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
                      NEW
                    </span>
                  )}
                  {product.discount && (
                    <span className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
                      -{product.discount}%
                    </span>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="absolute top-4 right-4 flex flex-col space-y-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <button className="bg-white text-gray-700 hover:text-red-500 p-2 rounded-full shadow-lg transition-colors">
                    <i className="ri-heart-line text-lg"></i>
                  </button>
                  <button className="bg-white text-gray-700 hover:text-yellow-500 p-2 rounded-full shadow-lg transition-colors">
                    <i className="ri-eye-line text-lg"></i>
                  </button>
                </div>

                {/* Quick Add Button */}
                <div className="absolute bottom-4 left-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <Button className="w-full" size="sm">
                    <i className="ri-shopping-cart-line mr-2"></i>
                    Quick Add
                  </Button>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-lg font-semibold text-black mb-2 line-clamp-2">
                  {product.name}
                </h3>
                
                <div className="flex items-center mb-3">
                  <div className="flex text-yellow-500">
                    {[...Array(5)].map((_, i) => (
                      <i key={i} className={`ri-star-${i < Math.floor(product.rating) ? 'fill' : 'line'} text-sm`}></i>
                    ))}
                  </div>
                  <span className="text-gray-500 text-sm ml-2">({product.reviews})</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex flex-col">
                    {product.discount ? (
                      <>
                        <span className="text-lg font-bold text-black">
                          {formatPrice(Math.round(product.price * (1 - product.discount / 100)))}
                        </span>
                        <span className="text-sm text-gray-500 line-through">
                          {formatPrice(product.price)}
                        </span>
                      </>
                    ) : (
                      <span className="text-lg font-bold text-black">
                        {formatPrice(product.price)}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-green-600 text-sm font-medium">In Stock</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Load More Button */}
        <div className="text-center">
          <Button size="lg" variant="outline" className="border-black text-black hover:bg-black hover:text-white">
            Load More Products
            <i className="ri-refresh-line ml-2"></i>
          </Button>
        </div>
      </div>
    </section>
  );
}
