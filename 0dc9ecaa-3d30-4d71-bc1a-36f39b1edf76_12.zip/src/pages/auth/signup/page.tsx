
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Button from '../../../components/base/Button';
import { signUp, signInWithGoogle, signInWithFacebook } from '../../../lib/supabase';

export default function SignUp() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: '',
    agreedToTerms: false
  });
  const [isLoading, setIsLoading] = useState(false);
  const [socialLoading, setSocialLoading] = useState<string | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.fullName.trim()) newErrors.fullName = 'Full name is required';
    if (!formData.email.trim()) newErrors.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = 'Email is invalid';
    
    if (!formData.password) newErrors.password = 'Password is required';
    else if (formData.password.length < 6) newErrors.password = 'Password must be at least 6 characters';
    
    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }
    
    if (!formData.agreedToTerms) {
      newErrors.agreedToTerms = 'You must agree to the terms and conditions';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsLoading(true);
    setMessage(null);
    
    try {
      const { data, error } = await signUp(
        formData.email,
        formData.password,
        formData.fullName,
        formData.phone
      );

      if (error) {
        setMessage({ 
          type: 'error', 
          text: error.message || 'Failed to create account. Please try again.' 
        });
      } else {
        setMessage({ 
          type: 'success', 
          text: 'Account created successfully! Please check your email for verification.' 
        });
        
        // If user is immediately signed in (email confirmation disabled)
        if (data.user && !data.user.email_confirmed_at) {
          setTimeout(() => {
            navigate('/dashboard');
          }, 2000);
        }
      }
      
    } catch (error) {
      console.error('Signup error:', error);
      setMessage({ 
        type: 'error', 
        text: 'Failed to create account. Please try again.' 
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSocialLogin = async (provider: 'google' | 'facebook') => {
    setSocialLoading(provider);
    setMessage(null);
    
    try {
      let result;
      if (provider === 'google') {
        result = await signInWithGoogle();
      } else {
        result = await signInWithFacebook();
      }

      if (result.error) {
        setMessage({ 
          type: 'error', 
          text: `Failed to sign up with ${provider === 'google' ? 'Google' : 'Facebook'}. Please try again.` 
        });
      }
      // Note: For OAuth, the redirect happens automatically on success
      
    } catch (error) {
      console.error(`${provider} login error:`, error);
      setMessage({ 
        type: 'error', 
        text: `Failed to sign up with ${provider === 'google' ? 'Google' : 'Facebook'}. Please try again.` 
      });
    } finally {
      setSocialLoading(null);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8"
         style={{
           backgroundImage: `linear-gradient(rgba(255, 255, 255, 0.95), rgba(255, 255, 255, 0.95)), url('https://readdy.ai/api/search-image?query=Modern%20e-commerce%20shopping%20background%20with%20premium%20furniture%20and%20construction%20materials%20in%20soft%20focus%2C%20elegant%20warehouse%20setting%20with%20golden%20yellow%20accents%2C%20professional%20Tanzania%20marketplace%20atmosphere%2C%20light%20and%20airy%20feel&width=1920&height=1080&seq=auth-bg&orientation=landscape')`
         }}>
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <img 
            src="https://static.readdy.ai/image/2e1029d6ff4bf81528d7a00cbe43730c/b0927985bd43a4b7c33f0ee0bdb851be.png" 
            alt="Freedom Select Logo" 
            className="h-16 w-auto"
          />
        </div>
        <h2 className="mt-6 text-center text-3xl font-bold text-gray-900">
          Create your account
        </h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          Join Freedom Select and start shopping
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow-lg sm:rounded-lg sm:px-10 border border-gray-200">
          {/* Message Display */}
          {message && (
            <div className={`mb-6 p-4 rounded-md ${
              message.type === 'success' 
                ? 'bg-green-50 border border-green-200 text-green-800' 
                : 'bg-red-50 border border-red-200 text-red-800'
            }`}>
              <div className="flex items-center">
                <i className={`${
                  message.type === 'success' ? 'ri-check-circle-line' : 'ri-error-warning-line'
                } mr-2`}></i>
                <span className="text-sm">{message.text}</span>
              </div>
            </div>
          )}

          {/* Social Login Buttons */}
          <div className="space-y-3 mb-6">
            <Button
              onClick={() => handleSocialLogin('google')}
              variant="outline"
              className="w-full border-gray-300 text-gray-700 hover:bg-gray-50"
              disabled={socialLoading === 'google' || isLoading}
            >
              {socialLoading === 'google' ? (
                <>
                  <i className="ri-loader-4-line animate-spin mr-3 text-red-500"></i>
                  Connecting to Google...
                </>
              ) : (
                <>
                  <i className="ri-google-fill mr-3 text-red-500"></i>
                  Continue with Google
                </>
              )}
            </Button>
            <Button
              onClick={() => handleSocialLogin('facebook')}
              variant="outline"
              className="w-full border-gray-300 text-gray-700 hover:bg-gray-50"
              disabled={socialLoading === 'facebook' || isLoading}
            >
              {socialLoading === 'facebook' ? (
                <>
                  <i className="ri-loader-4-line animate-spin mr-3 text-blue-600"></i>
                  Connecting to Facebook...
                </>
              ) : (
                <>
                  <i className="ri-facebook-fill mr-3 text-blue-600"></i>
                  Continue with Facebook
                </>
              )}
            </Button>
          </div>

          <div className="relative mb-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-300" />
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-gray-500">Or continue with email</span>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="fullName" className="block text-sm font-medium text-gray-700">
                Full Name
              </label>
              <div className="mt-1 relative">
                <input
                  id="fullName"
                  name="fullName"
                  type="text"
                  value={formData.fullName}
                  onChange={handleChange}
                  className={`appearance-none block w-full px-3 py-2 border ${errors.fullName ? 'border-red-300' : 'border-gray-300'} rounded-md placeholder-gray-400 focus:outline-none focus:ring-yellow-500 focus:border-yellow-500 sm:text-sm`}
                  placeholder="Enter your full name"
                />
                <i className="ri-user-line absolute right-3 top-2.5 text-gray-400"></i>
              </div>
              {errors.fullName && <p className="mt-1 text-sm text-red-600">{errors.fullName}</p>}
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                Email Address
              </label>
              <div className="mt-1 relative">
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  className={`appearance-none block w-full px-3 py-2 border ${errors.email ? 'border-red-300' : 'border-gray-300'} rounded-md placeholder-gray-400 focus:outline-none focus:ring-yellow-500 focus:border-yellow-500 sm:text-sm`}
                  placeholder="Enter your email"
                />
                <i className="ri-mail-line absolute right-3 top-2.5 text-gray-400"></i>
              </div>
              {errors.email && <p className="mt-1 text-sm text-red-600">{errors.email}</p>}
            </div>

            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                Phone Number <span className="text-gray-400">(Optional)</span>
              </label>
              <div className="mt-1 relative">
                <input
                  id="phone"
                  name="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={handleChange}
                  className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md placeholder-gray-400 focus:outline-none focus:ring-yellow-500 focus:border-yellow-500 sm:text-sm"
                  placeholder="+255 XXX XXX XXX"
                />
                <i className="ri-phone-line absolute right-3 top-2.5 text-gray-400"></i>
              </div>
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                Password
              </label>
              <div className="mt-1 relative">
                <input
                  id="password"
                  name="password"
                  type="password"
                  value={formData.password}
                  onChange={handleChange}
                  className={`appearance-none block w-full px-3 py-2 border ${errors.password ? 'border-red-300' : 'border-gray-300'} rounded-md placeholder-gray-400 focus:outline-none focus:ring-yellow-500 focus:border-yellow-500 sm:text-sm`}
                  placeholder="Create a password"
                />
                <i className="ri-lock-line absolute right-3 top-2.5 text-gray-400"></i>
              </div>
              {errors.password && <p className="mt-1 text-sm text-red-600">{errors.password}</p>}
            </div>

            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700">
                Confirm Password
              </label>
              <div className="mt-1 relative">
                <input
                  id="confirmPassword"
                  name="confirmPassword"
                  type="password"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  className={`appearance-none block w-full px-3 py-2 border ${errors.confirmPassword ? 'border-red-300' : 'border-gray-300'} rounded-md placeholder-gray-400 focus:outline-none focus:ring-yellow-500 focus:border-yellow-500 sm:text-sm`}
                  placeholder="Confirm your password"
                />
                <i className="ri-lock-line absolute right-3 top-2.5 text-gray-400"></i>
              </div>
              {errors.confirmPassword && <p className="mt-1 text-sm text-red-600">{errors.confirmPassword}</p>}
            </div>

            <div className="flex items-center">
              <input
                id="agreedToTerms"
                name="agreedToTerms"
                type="checkbox"
                checked={formData.agreedToTerms}
                onChange={handleChange}
                className="h-4 w-4 text-yellow-500 focus:ring-yellow-500 border-gray-300 rounded"
              />
              <label htmlFor="agreedToTerms" className="ml-2 block text-sm text-gray-900">
                I agree to the{' '}
                <Link to="/terms" className="text-yellow-600 hover:text-yellow-500">
                  Terms of Service
                </Link>{' '}
                and{' '}
                <Link to="/privacy" className="text-yellow-600 hover:text-yellow-500">
                  Privacy Policy
                </Link>
              </label>
            </div>
            {errors.agreedToTerms && <p className="text-sm text-red-600">{errors.agreedToTerms}</p>}

            <div>
              <Button
                type="submit"
                className="w-full flex justify-center"
                disabled={isLoading || socialLoading !== null}
              >
                {isLoading ? (
                  <>
                    <i className="ri-loader-4-line animate-spin mr-2"></i>
                    Creating Account...
                  </>
                ) : (
                  <>
                    <i className="ri-user-add-line mr-2"></i>
                    Create Account
                  </>
                )}
              </Button>
            </div>
          </form>

          <div className="mt-6">
            <div className="text-center">
              <span className="text-sm text-gray-600">
                Already have an account?{' '}
                <Link to="/auth/login" className="font-medium text-yellow-600 hover:text-yellow-500">
                  Sign in here
                </Link>
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
