
import Header from '../../components/feature/Header';
import Hero from '../../components/feature/Hero';
import CategoryShowcase from '../../components/feature/CategoryShowcase';
import ProductCarousel from '../../components/feature/ProductCarousel';
import Features from '../../components/feature/Features';
import ProductGrid from '../../components/feature/ProductGrid';
import Newsletter from '../../components/feature/Newsletter';
import Footer from '../../components/feature/Footer';

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Hero />
      <CategoryShowcase />
      <ProductCarousel />
      <Features />
      <ProductGrid />
      <Newsletter />
      <Footer />
    </div>
  );
}
