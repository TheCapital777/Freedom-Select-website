
import { Link } from 'react-router-dom';

interface Category {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  productCount: number;
  image: string;
  isAvailable: boolean;
}

export default function CategoryGrid() {
  const categories: Category[] = [
    {
      id: '1',
      name: 'Premium Furniture',
      description: 'Modern and luxury furniture for your home',
      icon: 'ri-sofa-line',
      color: 'bg-blue-500',
      productCount: 150,
      image: 'https://readdy.ai/api/search-image?query=Modern%20furniture%20showroom%20with%20premium%20sofas%2C%20dining%20sets%2C%20and%20bedroom%20furniture%2C%20elegant%20interior%20design%2C%20luxury%20home%20furnishing&width=300&height=200&seq=cat-furniture&orientation=landscape',
      isAvailable: true
    },
    {
      id: '2',
      name: 'Construction Supplies',
      description: 'Quality materials for your building projects',
      icon: 'ri-hammer-line',
      color: 'bg-orange-500',
      productCount: 120,
      image: 'https://readdy.ai/api/search-image?query=Construction%20materials%20warehouse%20with%20cement%20bags%2C%20steel%20bars%2C%20roofing%20materials%2C%20building%20supplies%20organized%20professionally&width=300&height=200&seq=cat-construction&orientation=landscape',
      isAvailable: true
    },
    {
      id: '3',
      name: 'Electronics',
      description: 'Latest gadgets and home appliances',
      icon: 'ri-smartphone-line',
      color: 'bg-purple-500',
      productCount: 0,
      image: 'https://readdy.ai/api/search-image?query=Modern%20electronics%20store%20with%20smartphones%2C%20laptops%2C%20home%20appliances%2C%20technology%20products%20display%2C%20clean%20retail%20environment&width=300&height=200&seq=cat-electronics&orientation=landscape',
      isAvailable: false
    },
    {
      id: '4',
      name: 'Home & Garden',
      description: 'Everything for your outdoor and indoor spaces',
      icon: 'ri-plant-line',
      color: 'bg-green-500',
      productCount: 0,
      image: 'https://readdy.ai/api/search-image?query=Garden%20center%20with%20outdoor%20furniture%2C%20plants%2C%20gardening%20tools%2C%20home%20improvement%20supplies%2C%20beautiful%20outdoor%20living%20space&width=300&height=200&seq=cat-garden&orientation=landscape',
      isAvailable: false
    }
  ];

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Shop by Category</h2>
        <Link to="/categories" className="text-yellow-600 hover:text-yellow-500 font-medium">
          View All Categories
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {categories.map((category) => (
          <div key={category.id} className="group relative overflow-hidden">
            {category.isAvailable ? (
              <Link
                to={`/categories/${category.id}`}
                className="block bg-white rounded-xl shadow-sm border border-gray-200 hover:shadow-lg transition-all duration-300"
              >
                {/* Category Image */}
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={category.image}
                    alt={category.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"></div>
                  
                  {/* Category Icon */}
                  <div className={`absolute top-4 right-4 ${category.color} text-white p-2 rounded-lg`}>
                    <i className={`${category.icon} text-lg`}></i>
                  </div>

                  {/* Product Count */}
                  <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1">
                    <span className="text-sm font-medium text-gray-900">
                      {category.productCount}+ items
                    </span>
                  </div>
                </div>

                {/* Category Info */}
                <div className="p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2 group-hover:text-yellow-600 transition-colors">
                    {category.name}
                  </h3>
                  <p className="text-gray-600 text-sm mb-4">
                    {category.description}
                  </p>
                  <div className="flex items-center text-yellow-600 font-medium text-sm">
                    Shop Now <i className="ri-arrow-right-line ml-1 group-hover:translate-x-1 transition-transform"></i>
                  </div>
                </div>
              </Link>
            ) : (
              <div className="block bg-white rounded-xl shadow-sm border border-gray-200 relative">
                {/* Coming Soon Overlay */}
                <div className="absolute inset-0 bg-gray-50/90 backdrop-blur-sm rounded-xl z-10 flex items-center justify-center">
                  <div className="text-center">
                    <div className="bg-yellow-500 text-black px-4 py-2 rounded-full font-semibold text-sm mb-2">
                      Coming Soon
                    </div>
                    <button className="text-yellow-600 hover:text-yellow-500 font-medium text-sm">
                      Notify Me
                    </button>
                  </div>
                </div>

                {/* Category Image */}
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={category.image}
                    alt={category.name}
                    className="w-full h-full object-cover grayscale opacity-50"
                  />
                  
                  {/* Category Icon */}
                  <div className={`absolute top-4 right-4 ${category.color} text-white p-2 rounded-lg opacity-50`}>
                    <i className={`${category.icon} text-lg`}></i>
                  </div>
                </div>

                {/* Category Info */}
                <div className="p-6">
                  <h3 className="text-lg font-semibold text-gray-500 mb-2">
                    {category.name}
                  </h3>
                  <p className="text-gray-400 text-sm mb-4">
                    {category.description}
                  </p>
                  <div className="flex items-center text-gray-400 font-medium text-sm">
                    Coming Soon <i className="ri-time-line ml-1"></i>
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
