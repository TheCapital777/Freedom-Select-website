
import { Link } from 'react-router-dom';

export default function QuickActions() {
  const actions = [
    {
      title: 'Browse Furniture',
      description: 'Explore our premium furniture collection',
      icon: 'ri-sofa-line',
      color: 'bg-blue-500',
      link: '/categories/furniture'
    },
    {
      title: 'Construction Supplies',
      description: 'Find all your building materials',
      icon: 'ri-hammer-line',
      color: 'bg-orange-500',
      link: '/categories/construction'
    },
    {
      title: 'Track Orders',
      description: 'Check your order status',
      icon: 'ri-truck-line',
      color: 'bg-green-500',
      link: '/orders'
    },
    {
      title: 'My Wishlist',
      description: 'View saved items',
      icon: 'ri-heart-line',
      color: 'bg-red-500',
      link: '/wishlist'
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {actions.map((action, index) => (
        <Link
          key={index}
          to={action.link}
          className="bg-white rounded-xl shadow-sm p-6 border border-gray-200 hover:shadow-md transition-all duration-200 group"
        >
          <div className="flex items-center space-x-4">
            <div className={`${action.color} text-white p-3 rounded-lg group-hover:scale-105 transition-transform`}>
              <i className={`${action.icon} text-xl`}></i>
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-gray-900 group-hover:text-yellow-600 transition-colors">
                {action.title}
              </h3>
              <p className="text-sm text-gray-600 mt-1">
                {action.description}
              </p>
            </div>
            <i className="ri-arrow-right-line text-gray-400 group-hover:text-yellow-500 transition-colors"></i>
          </div>
        </Link>
      ))}
    </div>
  );
}
