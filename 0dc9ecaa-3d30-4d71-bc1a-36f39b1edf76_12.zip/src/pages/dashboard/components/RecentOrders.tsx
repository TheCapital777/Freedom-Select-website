
import { Link } from 'react-router-dom';
import Button from '../../../components/base/Button';

interface Order {
  id: string;
  orderNumber: string;
  date: string;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  items: number;
  total: number;
  image: string;
  productName: string;
}

export default function RecentOrders() {
  const orders: Order[] = [
    {
      id: '1',
      orderNumber: 'FS-2024-001',
      date: '2024-01-20',
      status: 'delivered',
      items: 2,
      total: 850000,
      image: 'https://readdy.ai/api/search-image?query=Modern%20luxury%20sofa%20set%20in%20living%20room%20setting%2C%20premium%20furniture%2C%20contemporary%20design%2C%20clean%20product%20photography%2C%20elegant%20interior%20decoration&width=200&height=150&seq=order-sofa&orientation=landscape',
      productName: 'Modern Luxury Sofa Set'
    },
    {
      id: '2',
      orderNumber: 'FS-2024-002',
      date: '2024-01-18',
      status: 'shipped',
      items: 5,
      total: 320000,
      image: 'https://readdy.ai/api/search-image?query=Construction%20materials%20cement%20bags%20and%20building%20supplies%20stacked%20professionally%2C%20industrial%20construction%20materials%20photography&width=200&height=150&seq=order-cement&orientation=landscape',
      productName: 'Construction Materials Bundle'
    },
    {
      id: '3',
      orderNumber: 'FS-2024-003',
      date: '2024-01-15',
      status: 'processing',
      items: 1,
      total: 450000,
      image: 'https://readdy.ai/api/search-image?query=Executive%20office%20chair%20in%20premium%20leather%2C%20modern%20office%20furniture%2C%20professional%20seating%2C%20clean%20product%20photography&width=200&height=150&seq=order-chair&orientation=landscape',
      productName: 'Executive Office Chair'
    }
  ];

  const getStatusColor = (status: Order['status']) => {
    switch (status) {
      case 'delivered':
        return 'bg-green-100 text-green-800';
      case 'shipped':
        return 'bg-blue-100 text-blue-800';
      case 'processing':
        return 'bg-yellow-100 text-yellow-800';
      case 'pending':
        return 'bg-gray-100 text-gray-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: Order['status']) => {
    switch (status) {
      case 'delivered':
        return 'ri-check-double-line';
      case 'shipped':
        return 'ri-truck-line';
      case 'processing':
        return 'ri-timer-line';
      case 'pending':
        return 'ri-time-line';
      case 'cancelled':
        return 'ri-close-circle-line';
      default:
        return 'ri-question-line';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const formatPrice = (price: number) => {
    return `TZS ${price.toLocaleString()}`;
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold text-gray-900">Recent Orders</h2>
          <Link to="/orders" className="text-yellow-600 hover:text-yellow-500 font-medium text-sm">
            View All Orders
          </Link>
        </div>
      </div>

      <div className="divide-y divide-gray-200">
        {orders.map((order) => (
          <div key={order.id} className="p-6 hover:bg-gray-50 transition-colors">
            <div className="flex items-center space-x-4">
              {/* Order Image */}
              <div className="flex-shrink-0">
                <img
                  src={order.image}
                  alt={order.productName}
                  className="h-16 w-20 object-cover rounded-lg"
                />
              </div>

              {/* Order Details */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-medium text-gray-900 truncate">
                    {order.orderNumber}
                  </h3>
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                    <i className={`${getStatusIcon(order.status)} mr-1`}></i>
                    {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                  </span>
                </div>
                
                <p className="text-sm text-gray-600 mb-1 truncate">
                  {order.productName} {order.items > 1 && `+ ${order.items - 1} more items`}
                </p>
                
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">
                    {formatDate(order.date)}
                  </span>
                  <span className="font-medium text-gray-900">
                    {formatPrice(order.total)}
                  </span>
                </div>
              </div>

              {/* Actions */}
              <div className="flex-shrink-0 flex items-center space-x-2">
                {order.status === 'delivered' && (
                  <Button size="sm" variant="outline" className="border-yellow-500 text-yellow-600 hover:bg-yellow-50">
                    <i className="ri-repeat-line mr-1"></i>
                    Reorder
                  </Button>
                )}
                {(order.status === 'shipped' || order.status === 'processing') && (
                  <Button size="sm" variant="outline" className="border-blue-500 text-blue-600 hover:bg-blue-50">
                    <i className="ri-map-pin-line mr-1"></i>
                    Track
                  </Button>
                )}
                <Link 
                  to={`/orders/${order.id}`}
                  className="text-gray-400 hover:text-gray-600 p-1"
                >
                  <i className="ri-arrow-right-line"></i>
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>

      {orders.length === 0 && (
        <div className="p-8 text-center">
          <i className="ri-shopping-bag-line text-4xl text-gray-300 mb-4"></i>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No orders yet</h3>
          <p className="text-gray-600 mb-4">Start shopping to see your orders here</p>
          <Button>
            <i className="ri-store-line mr-2"></i>
            Start Shopping
          </Button>
        </div>
      )}
    </div>
  );
}
