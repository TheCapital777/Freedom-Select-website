
import Button from '../../../components/base/Button';

interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  rating: number;
  reviews: number;
  category: string;
  discount?: number;
}

export default function Recommendations() {
  const recommendedProducts: Product[] = [
    {
      id: '1',
      name: 'Premium Dining Table Set',
      price: 1250000,
      originalPrice: 1500000,
      image: 'https://readdy.ai/api/search-image?query=Elegant%20dining%20table%20set%20with%20six%20chairs%20in%20modern%20design%2C%20premium%20wood%20finish%2C%20contemporary%20dining%20room%20furniture%2C%20clean%20product%20photography&width=250&height=200&seq=rec-dining&orientation=landscape',
      rating: 4.8,
      reviews: 124,
      category: 'Furniture',
      discount: 17
    },
    {
      id: '2',
      name: 'Professional Paint Set',
      price: 180000,
      image: 'https://readdy.ai/api/search-image?query=Professional%20paint%20cans%20and%20brushes%20set%20for%20construction%20and%20home%20improvement%2C%20various%20colors%2C%20building%20materials%20photography&width=250&height=200&seq=rec-paint&orientation=landscape',
      rating: 4.6,
      reviews: 89,
      category: 'Construction'
    },
    {
      id: '3',
      name: 'Luxury Bedroom Wardrobe',
      price: 890000,
      image: 'https://readdy.ai/api/search-image?query=Modern%20luxury%20wardrobe%20with%20sliding%20doors%2C%20spacious%20bedroom%20furniture%2C%20contemporary%20closet%20design%2C%20premium%20finish&width=250&height=200&seq=rec-wardrobe&orientation=landscape',
      rating: 4.9,
      reviews: 67,
      category: 'Furniture'
    },
    {
      id: '4',
      name: 'Electrical Wire Bundle',
      price: 95000,
      image: 'https://readdy.ai/api/search-image?query=Professional%20electrical%20wiring%20cables%20for%20construction%2C%20copper%20wire%20bundles%2C%20electrical%20supplies%20for%20building%20projects&width=250&height=200&seq=rec-wire&orientation=landscape',
      rating: 4.5,
      reviews: 156,
      category: 'Construction'
    }
  ];

  const formatPrice = (price: number) => {
    return `TZS ${price.toLocaleString()}`;
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">Recommended for You</h2>
            <p className="text-gray-600 text-sm mt-1">Based on your browsing history and preferences</p>
          </div>
          <Button variant="outline" size="sm">
            <i className="ri-refresh-line mr-2"></i>
            Refresh
          </Button>
        </div>
      </div>

      <div className="p-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {recommendedProducts.map((product) => (
            <div key={product.id} className="group cursor-pointer" data-product-shop>
              <div className="relative overflow-hidden rounded-lg mb-4">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                
                {/* Discount Badge */}
                {product.discount && (
                  <div className="absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded-full text-xs font-semibold">
                    -{product.discount}%
                  </div>
                )}

                {/* Category Badge */}
                <div className="absolute top-2 right-2 bg-yellow-500 text-black px-2 py-1 rounded-full text-xs font-semibold">
                  {product.category}
                </div>

                {/* Quick Actions */}
                <div className="absolute bottom-2 left-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="flex space-x-2">
                    <Button size="sm" className="flex-1 text-xs">
                      <i className="ri-shopping-cart-line mr-1"></i>
                      Add to Cart
                    </Button>
                    <button className="bg-white text-gray-700 hover:text-red-500 p-2 rounded-lg shadow-lg transition-colors">
                      <i className="ri-heart-line text-sm"></i>
                    </button>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="font-medium text-gray-900 group-hover:text-yellow-600 transition-colors line-clamp-2">
                  {product.name}
                </h3>
                
                <div className="flex items-center space-x-1">
                  <div className="flex text-yellow-500">
                    {[...Array(5)].map((_, i) => (
                      <i key={i} className={`ri-star-${i < Math.floor(product.rating) ? 'fill' : 'line'} text-xs`}></i>
                    ))}
                  </div>
                  <span className="text-gray-500 text-xs">({product.reviews})</span>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="font-semibold text-gray-900">
                      {formatPrice(product.price)}
                    </span>
                    {product.originalPrice && (
                      <span className="text-sm text-gray-500 line-through">
                        {formatPrice(product.originalPrice)}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-8">
          <Button variant="outline" className="border-yellow-500 text-yellow-600 hover:bg-yellow-50">
            <i className="ri-eye-line mr-2"></i>
            View More Recommendations
          </Button>
        </div>
      </div>
    </div>
  );
}
