
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import DashboardHeader from './components/DashboardHeader';
import QuickActions from './components/QuickActions';
import RecentOrders from './components/RecentOrders';
import Recommendations from './components/Recommendations';
import CategoryGrid from './components/CategoryGrid';

export default function Dashboard() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [userProfile, setUserProfile] = useState({
    id: '',
    fullName: '',
    email: '',
    profilePicture: null,
    memberSince: ''
  });

  useEffect(() => {
    if (user) {
      setUserProfile({
        id: user.id,
        fullName: user.user_metadata?.full_name || user.email?.split('@')[0] || 'User',
        email: user.email || '',
        profilePicture: user.user_metadata?.avatar_url || null,
        memberSince: new Date(user.created_at).toISOString().split('T')[0]
      });
    }
  }, [user]);

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth/login');
    }
  }, [user, loading, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <i className="ri-loader-4-line animate-spin text-4xl text-yellow-500 mb-4"></i>
          <p className="text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <i className="ri-loader-4-line animate-spin text-4xl text-yellow-500 mb-4"></i>
          <p className="text-gray-600">Redirecting to login...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <DashboardHeader user={userProfile} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome back, {userProfile.fullName.split(' ')[0]}! 👋
          </h1>
          <p className="text-gray-600">
            Ready to continue shopping? Check out what's new and your recent activity.
          </p>
        </div>

        {/* Quick Actions */}
        <QuickActions />

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          {/* Left Column - Recent Orders */}
          <div className="lg:col-span-2">
            <RecentOrders />
          </div>
          
          {/* Right Column - Quick Stats */}
          <div className="space-y-6">
            {/* Account Stats */}
            <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Account Overview</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Total Orders</span>
                  <span className="font-semibold text-gray-900">12</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Total Spent</span>
                  <span className="font-semibold text-gray-900">TZS 2,480,000</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Saved Items</span>
                  <span className="font-semibold text-gray-900">8</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Member Since</span>
                  <span className="font-semibold text-gray-900">
                    {new Date(userProfile.memberSince).toLocaleDateString('en-US', { 
                      month: 'short', 
                      year: 'numeric' 
                    })}
                  </span>
                </div>
              </div>
            </div>

            {/* Loyalty Points */}
            <div className="bg-gradient-to-r from-yellow-500 to-yellow-600 rounded-xl shadow-sm p-6 text-white">
              <h3 className="text-lg font-semibold mb-2">Loyalty Points</h3>
              <div className="text-3xl font-bold mb-2">2,480</div>
              <p className="text-yellow-100 text-sm">
                Earn more points with every purchase!
              </p>
              <div className="mt-4">
                <div className="bg-white/20 rounded-full h-2">
                  <div className="bg-white rounded-full h-2 w-3/4"></div>
                </div>
                <p className="text-xs text-yellow-100 mt-1">
                  520 points to next reward level
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Categories Grid */}
        <CategoryGrid />

        {/* Recommendations */}
        <Recommendations />
      </main>
    </div>
  );
}
